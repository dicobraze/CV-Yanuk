﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KURSACH
{
    public partial class EditRecordWindow : Window
    {
        public EditRecordWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ProductContext())
            {
                int recordId;
                if (int.TryParse(RecordIDTextBox.Text, out recordId))
                {
                    string tableName = ((ComboBoxItem)TableComboBox.SelectedItem).Content.ToString();
                    switch (tableName)
                    {
                        case "Books":
                            UpdateBook(db, recordId);
                            break;
                        case "Customers":
                            UpdateCustomer(db, recordId);
                            break;
                        case "Employees":
                            UpdateEmployee(db, recordId);
                            break;
                        case "Orders":
                            UpdateOrder(db, recordId);
                            break;
                        case "Transactions":
                            UpdateTransaction(db, recordId);
                            break;
                        default:
                            MessageBox.Show("Please select a table.");
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid record ID.");
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private bool IsCustomerExist(ProductContext db, int customerId)
        {
            return db.Customers.Any(c => c.CustomerID == customerId);
        }

        private bool IsBookExist(ProductContext db, int bookId)
        {
            return db.Books.Any(b => b.BookID == bookId);
        }

        private bool IsEmployeeExist(ProductContext db, int employeeId)
        {
            return db.Employees.Any(emp => emp.EmployeeID == employeeId);
        }

        private void UpdateBook(ProductContext db, int bookId)
        {
            var book = db.Books.FirstOrDefault(b => b.BookID == bookId);
            if (book != null)
            {
                book.Genre = GenreTextBox.Text;
                book.Author = AuthorTextBox.Text;
                int publicationYear;
                if (int.TryParse(PublicationYearTextBox.Text, out publicationYear))
                {
                    book.PublicationYear = publicationYear;
                }
                decimal price;
                if (Decimal.TryParse(PriceTextBox.Text, out price))
                {
                    book.Price = price;
                }
                db.SaveChanges();
                MessageBox.Show("Book has been updated successfully.");
            }
            else
            {
                MessageBox.Show("No book found with this ID.");
            }
        }

        private void UpdateCustomer(ProductContext db, int customerId)
        {
            var customer = db.Customers.FirstOrDefault(c => c.CustomerID == customerId);
            if (customer != null)
            {
                customer.FirstName = FirstNameTextBox.Text;
                customer.LastName = LastNameTextBox.Text;
                customer.PhoneNumber = PhoneNumberTextBox.Text;
                customer.Address = AddressTextBox.Text;
                db.SaveChanges();
                MessageBox.Show("Customer has been updated successfully.");
            }
            else
            {
                MessageBox.Show("No customer found with this ID.");
            }
        }

        private void UpdateEmployee(ProductContext db, int employeeId)
        {
            var employee = db.Employees.FirstOrDefault(emp => emp.EmployeeID == employeeId);
            if (employee != null)
            {
                employee.FirstName = EmployeeFirstNameTextBox.Text;
                employee.LastName = EmployeeLastNameTextBox.Text;
                employee.PhoneNumber = EmployeePhoneNumberTextBox.Text;
                decimal salary;
                if (Decimal.TryParse(SalaryTextBox.Text, out salary))
                {
                    employee.Salary = salary;
                }
                db.SaveChanges();
                MessageBox.Show("Employee has been updated successfully.");
            }
            else
            {
                MessageBox.Show("No employee found with this ID.");
            }
        }

        private void UpdateOrder(ProductContext db, int orderId)
        {
            var order = db.Orders.FirstOrDefault(o => o.OrderID == orderId);
            if (order != null)
            {
                order.OrderDate = DateTime.Now; // Изменяем дату на текущую дату (пример)
                order.OrderStatus = OrderStatusTextBox.Text;
                int customerId;
                if (int.TryParse(OrderCustomerIDTextBox.Text, out customerId))
                {
                    if (!IsCustomerExist(db, customerId))
                    {
                        MessageBox.Show("Customer with this ID does not exist.");
                        return;
                    }
                    order.CustomerID = customerId;
                }
                int bookId;
                if (int.TryParse(OrderBookIDTextBox.Text, out bookId))
                {
                    if (!IsBookExist(db, bookId))
                    {
                        MessageBox.Show("Book with this ID does not exist.");
                        return;
                    }
                    order.BookID = bookId;
                }
                int employeeId;
                if (int.TryParse(OrderEmployeeIDTextBox.Text, out employeeId))
                {
                    if (!IsEmployeeExist(db, employeeId))
                    {
                        MessageBox.Show("Employee with this ID does not exist.");
                        return;
                    }
                    order.EmployeeID = employeeId;
                }
                db.SaveChanges();
                MessageBox.Show("Order has been updated successfully.");
            }
            else
            {
                MessageBox.Show("No order found with this ID.");
            }
        }

        private void UpdateTransaction(ProductContext db, int transactionId)
        {
            var transaction = db.Transactions.FirstOrDefault(t => t.TransactionID == transactionId);
            if (transaction != null)
            {
                transaction.TransactionDate = DateTime.Now; // Изменяем дату на текущую дату (пример)
                transaction.TransactionType = TransactionTypeTextBox.Text;
                int customerId;
                if (int.TryParse(TransactionCustomerIDTextBox.Text, out customerId))
                {
                    if (!IsCustomerExist(db, customerId))
                    {
                        MessageBox.Show("Customer with this ID does not exist.");
                        return;
                    }
                    transaction.CustomerID = customerId;
                }
                int bookId;
                if (int.TryParse(TransactionBookIDTextBox.Text, out bookId))
                {
                    if (!IsBookExist(db, bookId))
                    {
                        MessageBox.Show("Book with this ID does not exist.");
                        return;
                    }
                    transaction.BookID = bookId;
                }
                db.SaveChanges();
                MessageBox.Show("Transaction has been updated successfully.");
            }
            else
            {
                MessageBox.Show("No transaction found with this ID.");
            }
        }
    }
}
