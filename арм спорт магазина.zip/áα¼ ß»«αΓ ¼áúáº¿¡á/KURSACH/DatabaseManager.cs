﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace KURSACH
{
    public class DatabaseManager
    {
        private static string connectionString = "Server=(localdb)\\MSSQLLocaldb;Database=ManagerBook;Trusted_Connection=True;";

        public static List<Books> LoadBooks()
        {
            List<Books> books = new List<Books>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Books";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Books book = new Books
                    {
                        BookID = reader.GetInt32(0),
                        Genre = reader.GetString(1),
                        Author = reader.GetString(2),
                        PublicationYear = reader.GetInt32(3),
                        Price = reader.GetDecimal(4)
                    };

                    books.Add(book);
                }

                reader.Close();
            }

            return books;
        }

        public static List<Customers> LoadCustomers()
        {
            List<Customers> customers = new List<Customers>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Customers customer = new Customers
                    {
                        CustomerID = reader.GetInt32(0),
                        FirstName = reader.GetString(1),
                        LastName = reader.GetString(2),
                        PhoneNumber = reader.GetString(3),
                        Address = reader.GetString(4)
                    };

                    customers.Add(customer);
                }

                reader.Close();
            }

            return customers;
        }

        public static List<Employees> LoadEmployees()
        {
            List<Employees> employees = new List<Employees>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Employees";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Employees employee = new Employees
                    {
                        EmployeeID = reader.GetInt32(0),
                        FirstName = reader.GetString(1),
                        LastName = reader.GetString(2),
                        PhoneNumber = reader.GetString(3),
                        Salary = reader.GetDecimal(4)
                    };

                    employees.Add(employee);
                }

                reader.Close();
            }

            return employees;
        }

        public static List<Orders> LoadOrders()
        {
            List<Orders> orders = new List<Orders>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Orders";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Orders order = new Orders
                    {
                        OrderID = reader.GetInt32(0),
                        OrderDate = reader.GetDateTime(1),
                        OrderStatus = reader.GetString(2),
                        CustomerID = reader.GetInt32(3),
                        BookID = reader.GetInt32(4),
                        EmployeeID = reader.GetInt32(5)
                    };

                    orders.Add(order);
                }

                reader.Close();
            }

            return orders;
        }

        public static List<Transactions> LoadTransactions()
        {
            List<Transactions> transactions = new List<Transactions>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Transactions";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Transactions transaction = new Transactions
                    {
                        TransactionID = reader.GetInt32(0),
                        TransactionDate = reader.GetDateTime(1),
                        TransactionType = reader.GetString(2),
                        CustomerID = reader.GetInt32(3),
                        BookID = reader.GetInt32(4)
                    };

                    transactions.Add(transaction);
                }

                reader.Close();
            }

            return transactions;
        }

        // Методы AddBook, AddCustomer и AddEmployee остаются без изменений

        public void AddBook(Books book)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Books (Genre, Author, PublicationYear, Price) VALUES (@Genre, @Author, @PublicationYear, @Price)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Genre", book.Genre);
                command.Parameters.AddWithValue("@Author", book.Author);
                command.Parameters.AddWithValue("@PublicationYear", book.PublicationYear);
                command.Parameters.AddWithValue("@Price", book.Price);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void AddCustomer(Customers customer)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Customers (FirstName, LastName, PhoneNumber, Address) VALUES (@FirstName, @LastName, @PhoneNumber, @Address)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", customer.FirstName);
                command.Parameters.AddWithValue("@LastName", customer.LastName);
                command.Parameters.AddWithValue("@PhoneNumber", customer.PhoneNumber);
                command.Parameters.AddWithValue("@Address", customer.Address);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void AddEmployee(Employees employee)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Employees (FirstName, LastName, PhoneNumber, Salary) VALUES (@FirstName, @LastName, @PhoneNumber, @Salary)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                command.Parameters.AddWithValue("@LastName", employee.LastName);
                command.Parameters.AddWithValue("@PhoneNumber", employee.PhoneNumber);
                command.Parameters.AddWithValue("@Salary", employee.Salary);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void AddOrder(Orders order)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Orders (OrderDate, OrderStatus, CustomerID, BookID, EmployeeID) VALUES (@OrderDate, @OrderStatus, @CustomerID, @BookID, @EmployeeID)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                command.Parameters.AddWithValue("@OrderStatus", order.OrderStatus);
                command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                command.Parameters.AddWithValue("@BookID", order.BookID);
                command.Parameters.AddWithValue("@EmployeeID", order.EmployeeID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void AddTransaction(Transactions transaction)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Transactions (TransactionDate, TransactionType, CustomerID, BookID) VALUES (@TransactionDate, @TransactionType, @CustomerID, @BookID)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@TransactionDate", transaction.TransactionDate);
                command.Parameters.AddWithValue("@TransactionType", transaction.TransactionType);
                command.Parameters.AddWithValue("@CustomerID", transaction.CustomerID);
                command.Parameters.AddWithValue("@BookID", transaction.BookID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        // Остальные методы (UpdateBook, UpdateCustomer, UpdateEmployee, CheckCredentials) остаются без изменений

        public void UpdateBook(Books book)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Books SET Genre = @Genre, Author = @Author, PublicationYear = @PublicationYear, Price = @Price WHERE BookID = @BookID";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Genre", book.Genre);
                command.Parameters.AddWithValue("@Author", book.Author);
                command.Parameters.AddWithValue("@PublicationYear", book.PublicationYear);
                command.Parameters.AddWithValue("@Price", book.Price);
                command.Parameters.AddWithValue("@BookID", book.BookID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void UpdateCustomer(Customers customer)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Customers SET FirstName = @FirstName, LastName = @LastName, PhoneNumber = @PhoneNumber, Address = @Address WHERE CustomerID = @CustomerID";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", customer.FirstName);
                command.Parameters.AddWithValue("@LastName", customer.LastName);
                command.Parameters.AddWithValue("@PhoneNumber", customer.PhoneNumber);
                command.Parameters.AddWithValue("@Address", customer.Address);
                command.Parameters.AddWithValue("@CustomerID", customer.CustomerID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void UpdateEmployee(Employees employee)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Employees SET FirstName = @FirstName, LastName = @LastName, PhoneNumber = @PhoneNumber, Salary = @Salary WHERE EmployeeID = @EmployeeID";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                command.Parameters.AddWithValue("@LastName", employee.LastName);
                command.Parameters.AddWithValue("@PhoneNumber", employee.PhoneNumber);
                command.Parameters.AddWithValue("@Salary", employee.Salary);
                command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void UpdateOrder(Orders order)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Orders SET OrderDate = @OrderDate, OrderStatus = @OrderStatus, CustomerID = @CustomerID, BookID = @BookID, EmployeeID = @EmployeeID WHERE OrderID = @OrderID";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                command.Parameters.AddWithValue("@OrderStatus", order.OrderStatus);
                command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                command.Parameters.AddWithValue("@BookID", order.BookID);
                command.Parameters.AddWithValue("@EmployeeID", order.EmployeeID);
                command.Parameters.AddWithValue("@OrderID", order.OrderID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public void UpdateTransaction(Transactions transaction)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Transactions SET TransactionDate = @TransactionDate, TransactionType = @TransactionType, CustomerID = @CustomerID, BookID = @BookID WHERE TransactionID = @TransactionID";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@TransactionDate", transaction.TransactionDate);
                command.Parameters.AddWithValue("@TransactionType", transaction.TransactionType);
                command.Parameters.AddWithValue("@CustomerID", transaction.CustomerID);
                command.Parameters.AddWithValue("@BookID", transaction.BookID);
                command.Parameters.AddWithValue("@TransactionID", transaction.TransactionID);

                connection.Open();

                command.ExecuteNonQuery();
            }
        }

        public bool CheckCredentials(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        throw new Exception("User not found.");
                    }
                }
            }
        }
    }
}
