﻿using System;
using System.Windows;
using KURSACH;

namespace KURSACH
{
    public partial class AddRecordWindow : Window
    {
        private DatabaseManager databaseManager;

        public AddRecordWindow()
        {
            InitializeComponent();

            databaseManager = new DatabaseManager();
        }

        private void AddBook_Click(object sender, RoutedEventArgs e)
        {
            // Добавление книги
            Books book = new Books
            {
                Genre = txtBookGenre.Text,
                Author = txtBookAuthor.Text,
                PublicationYear = Convert.ToInt32(txtBookPublicationYear.Text),
                Price = Convert.ToDecimal(txtBookPrice.Text),
            };

            databaseManager.AddBook(book);
            MessageBox.Show("Book record added successfully.");

            // Очистка полей после добавления записи
            txtBookGenre.Text = string.Empty;
            txtBookAuthor.Text = string.Empty;
            txtBookPublicationYear.Text = string.Empty;
            txtBookPrice.Text = string.Empty;
        }

        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            // Добавление клиента
            Customers customer = new Customers
            {
                FirstName = txtCustomerFirstName.Text,
                LastName = txtCustomerLastName.Text,
                PhoneNumber = txtCustomerPhoneNumber.Text,
                Address = txtCustomerAddress.Text,
            };

            databaseManager.AddCustomer(customer);
            MessageBox.Show("Customer record added successfully.");

            // Очистка полей после добавления записи
            txtCustomerFirstName.Text = string.Empty;
            txtCustomerLastName.Text = string.Empty;
            txtCustomerPhoneNumber.Text = string.Empty;
            txtCustomerAddress.Text = string.Empty;
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            // Добавление сотрудника
            Employees employee = new Employees
            {
                FirstName = txtEmployeeFirstName.Text,
                LastName = txtEmployeeLastName.Text,
                PhoneNumber = txtEmployeePhoneNumber.Text,
                Salary = Convert.ToDecimal(txtEmployeeSalary.Text),
            };

            databaseManager.AddEmployee(employee);
            MessageBox.Show("Employee record added successfully.");

            // Очистка полей после добавления записи
            txtEmployeeFirstName.Text = string.Empty;
            txtEmployeeLastName.Text = string.Empty;
            txtEmployeePhoneNumber.Text = string.Empty;
            txtEmployeeSalary.Text = string.Empty;
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            // Добавление заказа
            Orders order = new Orders
            {
                OrderDate = Convert.ToDateTime(txtOrderDate.Text),
                OrderStatus = txtOrderStatus.Text,
                CustomerID = Convert.ToInt32(txtOrderCustomerID.Text),
                BookID = Convert.ToInt32(txtOrderBookID.Text),
                EmployeeID = Convert.ToInt32(txtOrderEmployeeID.Text),
            };

            databaseManager.AddOrder(order);
            MessageBox.Show("Order record added successfully.");

            // Очистка полей после добавления записи
            txtOrderDate.Text = string.Empty;
            txtOrderStatus.Text = string.Empty;
            txtOrderCustomerID.Text = string.Empty;
            txtOrderBookID.Text = string.Empty;
            txtOrderEmployeeID.Text = string.Empty;
        }

        private void AddTransaction_Click(object sender, RoutedEventArgs e)
        {
            // Добавление транзакции
            Transactions transaction = new Transactions
            {
                TransactionDate = Convert.ToDateTime(txtTransactionDate.Text),
                TransactionType = txtTransactionType.Text,
                CustomerID = Convert.ToInt32(txtTransactionCustomerID.Text),
                BookID = Convert.ToInt32(txtTransactionBookID.Text),
            };

            databaseManager.AddTransaction(transaction);
            MessageBox.Show("Transaction record added successfully.");

            // Очистка полей после добавления записи
            txtTransactionDate.Text = string.Empty;
            txtTransactionType.Text = string.Empty;
            txtTransactionCustomerID.Text = string.Empty;
            txtTransactionBookID.Text = string.Empty;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
