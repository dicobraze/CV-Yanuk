﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KURSACH
{
    public partial class ShowRecordsWindow : Window
    {
        public ShowRecordsWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            // Load data for each tab
            List<Books> books = DatabaseManager.LoadBooks();
            BooksDataGrid.ItemsSource = books;

            List<Customers> customers = DatabaseManager.LoadCustomers();
            CustomersDataGrid.ItemsSource = customers;

            List<Employees> employees = DatabaseManager.LoadEmployees();
            EmployeesDataGrid.ItemsSource = employees;

            List<Orders> orders = DatabaseManager.LoadOrders();
            OrdersDataGrid.ItemsSource = orders;

            List<Transactions> transactions = DatabaseManager.LoadTransactions();
            TransactionsDataGrid.ItemsSource = transactions;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
