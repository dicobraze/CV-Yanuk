﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KURSACH
{
    public partial class DeleteRecordWindow : Window
    {
        // Флаг для отслеживания вывода сообщения об успешном удалении
        private bool deletionMessageShown = false;

        public DeleteRecordWindow()
        {
            InitializeComponent();
            LoadComboBox(); // Загрузка списка таблиц в выпадающий список при запуске окна
        }

        private void LoadComboBox()
        {
            // Добавление названий таблиц в выпадающий список
            TableComboBox.Items.Add("Books");
            TableComboBox.Items.Add("Customers");
            TableComboBox.Items.Add("Employees");
            TableComboBox.Items.Add("Orders");
            TableComboBox.Items.Add("Transactions");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка выбранной таблицы
            if (TableComboBox.SelectedItem != null)
            {
                string selectedTable = TableComboBox.SelectedItem.ToString();

                if (selectedTable == "Books")
                    DeleteRecord(selectedTable, "BookID", RecordIDTextBox.Text);
                else if (selectedTable == "Customers")
                    DeleteRecord(selectedTable, "CustomerID", RecordIDTextBox.Text);
                else if (selectedTable == "Employees")
                    DeleteRecord(selectedTable, "EmployeeID", RecordIDTextBox.Text);
                else if (selectedTable == "Orders")
                    DeleteRecord(selectedTable, "OrderID", RecordIDTextBox.Text);
                else if (selectedTable == "Transactions")
                    DeleteRecord(selectedTable, "TransactionID", RecordIDTextBox.Text);
            }
            else
            {
                MessageBox.Show("Please select a table.");
            }
        }


        private void DeleteRecord(string selectedTable, string idColumnName, string id)
        {
            // Сброс флага перед каждым запросом на удаление
            deletionMessageShown = false;

            if (!string.IsNullOrEmpty(id))
            {
                int recordId;
                if (int.TryParse(id, out recordId))
                {
                    using (var db = new ProductContext())
                    {
                        bool recordDeleted = false; // Флаг для отслеживания успешного удаления записи

                        switch (selectedTable)
                        {
                            case "Books":
                                recordDeleted = DeleteBook(recordId);
                                break;
                            case "Customers":
                                recordDeleted = DeleteCustomer(recordId);
                                break;
                            case "Employees":
                                recordDeleted = DeleteEmployee(recordId);
                                break;
                            case "Orders":
                                recordDeleted = DeleteOrder(recordId);
                                break;
                            case "Transactions":
                                recordDeleted = DeleteTransaction(recordId);
                                break;
                            default:
                                MessageBox.Show($"Delete method for {selectedTable} not implemented.");
                                break;
                        }

                        // Проверяем, была ли запись успешно удалена перед выводом сообщения
                        if (recordDeleted)
                        {
                            MessageBox.Show($"{selectedTable} record has been deleted successfully.");
                            deletionMessageShown = true;
                            // Очистка поля ввода
                            RecordIDTextBox.Clear();
                        }
                    }
                }
                else
                {
                    MessageBox.Show($"Please enter a valid {idColumnName}.");
                }
            }
            else
            {
                MessageBox.Show($"Please enter a {idColumnName}.");
            }
        }

        private bool DeleteBook(int bookId)
        {
            using (var db = new ProductContext())
            {
                var book = db.Books.FirstOrDefault(b => b.BookID == bookId);
                if (book != null)
                {
                    db.Books.Remove(book);
                    db.SaveChanges();
                    return true; // Запись успешно удалена
                }
                else
                {
                    MessageBox.Show("No book found with this ID.");
                    return false; // Запись не найдена, удаление не выполнено
                }
            }
        }

        private bool DeleteCustomer(int customerId)
        {
            using (var db = new ProductContext())
            {
                var customer = db.Customers.FirstOrDefault(c => c.CustomerID == customerId);
                if (customer != null)
                {
                    db.Customers.Remove(customer);
                    db.SaveChanges();
                    return true; // Запись успешно удалена
                }
                else
                {
                    MessageBox.Show("No customer found with this ID.");
                    return false; // Запись не найдена, удаление не выполнено
                }
            }
        }

        private bool DeleteEmployee(int employeeId)
        {
            using (var db = new ProductContext())
            {
                var employee = db.Employees.FirstOrDefault(emp => emp.EmployeeID == employeeId);
                if (employee != null)
                {
                    db.Employees.Remove(employee);
                    db.SaveChanges();
                    return true; // Запись успешно удалена
                }
                else
                {
                    MessageBox.Show("No employee found with this ID.");
                    return false; // Запись не найдена, удаление не выполнено
                }
            }
        }

        private bool DeleteOrder(int orderId)
        {
            using (var db = new ProductContext())
            {
                var order = db.Orders.FirstOrDefault(o => o.OrderID == orderId);
                if (order != null)
                {
                    db.Orders.Remove(order);
                    db.SaveChanges();
                    return true; // Запись успешно удалена
                }
                else
                {
                    MessageBox.Show("No order found with this ID.");
                    return false; // Запись не найдена, удаление не выполнено
                }
            }
        }

        private bool DeleteTransaction(int transactionId)
        {
            using (var db = new ProductContext())
            {
                var transaction = db.Transactions.FirstOrDefault(t => t.TransactionID == transactionId);
                if (transaction != null)
                {
                    db.Transactions.Remove(transaction);
                    db.SaveChanges();
                    return true; // Запись успешно удалена
                }
                else
                {
                    MessageBox.Show("No transaction found with this ID.");
                    return false; // Запись не найдена, удаление не выполнено
                }
            }
        }



        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
